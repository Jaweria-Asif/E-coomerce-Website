﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_9442_
{
    class AC
    {
        protected int AcID;
        public AC(int ID)
        {
            this.AcID = ID;
        }
    }
}