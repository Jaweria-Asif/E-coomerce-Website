﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_9442_
{
    class OtherVehicle: Vehicle
    {
        private int id;
        public OtherVehicle(Engine eng, AC ac, int id) : base(eng,id)
        {

            this.id = id;
        }
        public override void display()
        {
            Console.WriteLine("the number of engine in car :" + engineID);
            Console.WriteLine("the number of ac in car: " + acID);
        }
    }
}
