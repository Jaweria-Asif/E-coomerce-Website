﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_9442_
{
    abstract class Vehicle
    {
        protected Engine engineID;
        protected AC acID;
        public Vehicle(Engine e, AC ac, int v)
        {
            this.engineID = e;
            this.acID = ac;

        }
        public Vehicle(Engine e, int v)
        {
            this.engineID = e;
        }
        abstract public void display();

    }

}
