﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_9442_
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine e = new Engine(1);
            AC a = new AC(1);
            LandVehicle v1 = new LandVehicle(e, a, 1);
            Driver dr1 = new Driver(1);
            Trip tr1 = new Trip(v1, dr1, 1);
            tr1.display();
            Console.ReadLine();
        }
    }
}
