﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_9442_
{
    class Trip
    {
        private int tripID;
        public Trip(Vehicle v, Driver d, int v_id)
        {
            this.tripID = v_id;
        }
        public void display()
        {
            Console.WriteLine("Trip no  : " + tripID + " is ready to go...");
        }

    }
}
