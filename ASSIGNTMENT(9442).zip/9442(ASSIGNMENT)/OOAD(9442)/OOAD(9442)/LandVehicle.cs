﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_9442_
{
    class LandVehicle: Vehicle
    {
        private int id;
        public LandVehicle(Engine e, AC a, int Land_Veh_ID) : base(e, a, Land_Veh_ID)
        {
            this.id = Land_Veh_ID;
        }
        public LandVehicle(Engine e, int Land_Veh_ID) : base(e, Land_Veh_ID)
        {
            this.id = Land_Veh_ID;
        }
        public override void display()
        {
            Console.WriteLine("Engine :" + engineID);
            Console.WriteLine("AC : " + acID);
        }
    }
}
