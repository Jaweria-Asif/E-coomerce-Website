﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_9442_
{
    class Engine
    {
        protected int EngineID;
        public Engine(int Id)
        {
            this.EngineID = Id;
        }
    }
}
