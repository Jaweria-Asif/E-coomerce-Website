﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOAD_9442_
{
    public class Driver
    {
        protected int driverID;
        public Driver()
        {
        }
        public Driver(int ID)
        {
            this.driverID = ID;
        }
        public void display()
        {
            Console.WriteLine("The Driver ID is : " + driverID);
        }
    }
}